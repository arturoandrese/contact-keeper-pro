/**
 * Derive a readable company name from a domain.
 * Examples:
 *   "tisal.cl" → "TISAL"
 *   "eldespacho.cl" → "EL DESPACHO"
 *   "walmartchile.cl" → "WALMART CHILE"
 *   "bancoestado.cl" → "BANCO ESTADO"
 */

// Common Spanish words that appear glued in domains — used to split compound names
const SPLIT_PREFIXES = [
  "el", "la", "las", "los", "del", "mi", "tu", "su",
  "banco", "grupo", "club", "red", "centro", "portal",
];

const SPLIT_SUFFIXES = [
  "chile", "online", "digital", "net", "web", "app", "pro",
];

/**
 * Split a compound domain word into readable parts.
 * "eldespacho" → "EL DESPACHO"
 * "walmartchile" → "WALMART CHILE"
 * "tisal" → "TISAL"
 */
export function splitDomainWord(word: string): string {
  const w = word.toLowerCase();

  // Try splitting a known prefix
  for (const prefix of SPLIT_PREFIXES) {
    if (w.startsWith(prefix) && w.length > prefix.length + 2) {
      const rest = w.slice(prefix.length);
      return `${prefix.toUpperCase()} ${splitDomainWord(rest).toUpperCase()}`;
    }
  }

  // Try splitting a known suffix
  for (const suffix of SPLIT_SUFFIXES) {
    if (w.endsWith(suffix) && w.length > suffix.length + 2) {
      const rest = w.slice(0, w.length - suffix.length);
      return `${rest.toUpperCase()} ${suffix.toUpperCase()}`;
    }
  }

  return w.toUpperCase();
}

/**
 * Extract company name from a domain string.
 * "tisal.cl" → "TISAL"
 * "eldespacho.cl" → "EL DESPACHO"
 */
export function extractCompanyFromDomain(domain: string): string {
  if (!domain) return "";
  // Remove protocol, www, trailing slash
  const clean = domain.toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/\/.*$/, "");
  // Get the base part before TLD
  const parts = clean.split(".");
  if (parts.length === 0) return domain.toUpperCase();
  const base = parts[0];
  if (!base) return domain.toUpperCase();
  return splitDomainWord(base);
}

// Keep the old function for backward compat but redirect to domain-based
export function simplifyCompanyName(name: string): string {
  if (!name || !name.trim()) return name;
  return name.trim().toUpperCase();
}
