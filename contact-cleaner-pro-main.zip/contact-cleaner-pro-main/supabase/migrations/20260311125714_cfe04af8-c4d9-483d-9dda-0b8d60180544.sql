
-- Bases history
CREATE TABLE public.bases (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  raw_count INTEGER NOT NULL DEFAULT 0,
  clean_count INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.bases ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read bases" ON public.bases FOR SELECT USING (true);
CREATE POLICY "Anyone can insert bases" ON public.bases FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update bases" ON public.bases FOR UPDATE USING (true);
CREATE POLICY "Anyone can delete bases" ON public.bases FOR DELETE USING (true);

-- Contacts per base
CREATE TABLE public.contacts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  base_id UUID NOT NULL REFERENCES public.bases(id) ON DELETE CASCADE,
  nombre TEXT NOT NULL DEFAULT '',
  apellido TEXT NOT NULL DEFAULT '',
  apellido2 TEXT NOT NULL DEFAULT '',
  empresa TEXT NOT NULL DEFAULT '',
  web TEXT NOT NULL DEFAULT '',
  mail1 TEXT NOT NULL DEFAULT '',
  mail2 TEXT NOT NULL DEFAULT '',
  mail3 TEXT NOT NULL DEFAULT '',
  mail4 TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.contacts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read contacts" ON public.contacts FOR SELECT USING (true);
CREATE POLICY "Anyone can insert contacts" ON public.contacts FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update contacts" ON public.contacts FOR UPDATE USING (true);
CREATE POLICY "Anyone can delete contacts" ON public.contacts FOR DELETE USING (true);

-- Learned domain email patterns
CREATE TABLE public.domain_patterns (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  domain TEXT NOT NULL,
  pattern TEXT NOT NULL,
  example_email TEXT NOT NULL DEFAULT '',
  confidence INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(domain, pattern)
);

ALTER TABLE public.domain_patterns ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read domain_patterns" ON public.domain_patterns FOR SELECT USING (true);
CREATE POLICY "Anyone can insert domain_patterns" ON public.domain_patterns FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update domain_patterns" ON public.domain_patterns FOR UPDATE USING (true);

CREATE INDEX idx_contacts_base_id ON public.contacts(base_id);
CREATE INDEX idx_domain_patterns_domain ON public.domain_patterns(domain);
