ALTER TABLE public.bases ADD COLUMN crossed boolean NOT NULL DEFAULT false;
ALTER TABLE public.bases ADD COLUMN crossed_at timestamp with time zone;