CREATE TABLE public.delivered_contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL DEFAULT '',
  apellido text NOT NULL DEFAULT '',
  empresa text NOT NULL DEFAULT '',
  empresa_short text NOT NULL DEFAULT '',
  web text NOT NULL DEFAULT '',
  mail text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.delivered_contacts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read delivered_contacts" ON public.delivered_contacts FOR SELECT TO public USING (true);
CREATE POLICY "Anyone can insert delivered_contacts" ON public.delivered_contacts FOR INSERT TO public WITH CHECK (true);
CREATE POLICY "Anyone can delete delivered_contacts" ON public.delivered_contacts FOR DELETE TO public USING (true);

CREATE UNIQUE INDEX delivered_contacts_unique_mail ON public.delivered_contacts (mail);