
-- Add times_contacted and last_contacted_at columns to delivered_contacts
ALTER TABLE public.delivered_contacts 
  ADD COLUMN IF NOT EXISTS times_contacted integer NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS last_contacted_at timestamp with time zone NOT NULL DEFAULT now();

-- Add UPDATE policy for delivered_contacts (currently missing)
CREATE POLICY "Anyone can update delivered_contacts"
  ON public.delivered_contacts
  FOR UPDATE
  TO public
  USING (true);
